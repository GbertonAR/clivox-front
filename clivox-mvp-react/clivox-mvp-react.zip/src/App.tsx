function App() {
  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 text-white">
      <div className="p-10 bg-white/10 rounded-2xl shadow-xl text-center max-w-md">
        <h1 className="text-4xl font-bold mb-4">👋 Bienvenido a Clivox</h1>
        <p className="text-lg">Tu nueva plataforma de clases online con IA</p>
        <a
          href="https://meet.jit.si/ClivoxDemo"
          target="_blank"
          className="mt-6 inline-block bg-white text-indigo-600 px-4 py-2 rounded-xl font-semibold hover:bg-gray-100 transition"
        >
          Entrar a la Demo
        </a>
      </div>
    </div>
  );
}
export default App;